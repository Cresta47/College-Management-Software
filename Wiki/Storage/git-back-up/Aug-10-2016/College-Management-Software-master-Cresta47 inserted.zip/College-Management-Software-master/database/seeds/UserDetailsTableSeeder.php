<?php
use Illuminate\Database\Seeder;

class UserDetailsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();

        $limit = 25;

        for ($i = 0; $i < $limit; $i++) {
            \DB::table('user_details')->insert([ //,
                'user_id' => $i+1,
                'first_name' => $faker->firstName,
                'last_name' => $faker->lastName,
                'dob' => $faker->dateTimeBetween('-30 years','now'),
                'gender' => $faker->randomElements(array('m','f'))
            ]);
        }
    }
}