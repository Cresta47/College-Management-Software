/**
* AngularJS Web Application Declaration
*/
var app = angular.module('app', ['ngRoute','ngResource']);