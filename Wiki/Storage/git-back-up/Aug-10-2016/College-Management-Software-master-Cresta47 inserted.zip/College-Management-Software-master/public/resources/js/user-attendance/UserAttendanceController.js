/**
* Controls the Blog
*/
app.controller('UserController', function ($scope, $location, $http) {
	console.log("Blog Controller reporting for duty.");
});

