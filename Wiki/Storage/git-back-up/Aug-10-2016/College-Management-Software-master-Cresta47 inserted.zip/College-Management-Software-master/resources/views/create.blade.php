<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create</title>
</head>
<body>
    <form method="POST" action="store">
        Name::<input name="name" type="text" placeholder="Enter your name">
        <br>
        Email::<input name="email" type="text" placeholder="Enter your email">
        <br>
        Password::<input name="password" type="password" placeholder="Enter your password">
        <input type="hidden" name="_token" value="{{csrf_token()}}">
        <input type="submit" value="submit" name="submit">
    </form>

</body>
</html>